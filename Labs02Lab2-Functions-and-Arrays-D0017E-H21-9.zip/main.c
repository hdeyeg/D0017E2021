#include <stdio.h>
#include <stdlib.h>

int c5();
int c6();
int c7();
int main(void) {
  printf("Chapter 5\n");

  c5();
  printf("\n\n");


  printf("Chapter 6\n");

  c6();
  printf("\n\n");


  printf("Chapter 7\n");

  c7();
  
  printf("\n\n");

return 0; 
}