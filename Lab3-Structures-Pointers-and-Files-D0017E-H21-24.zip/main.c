
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


int prog9();
int prog10();
int prog1415();


int main(void) {
prog9();
prog10();
prog1415();
return 0;
}
